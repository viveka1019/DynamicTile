sap.ui.define([
	"com/aramco/fiori/DynamicTileNew/test/unit/controller/Aramcotile.controller"
], function () {
	"use strict";
});