/*global QUnit*/

sap.ui.define([
	"com/aramco/fiori/DynamicTileNew/controller/Aramcotile.controller"
], function (Controller) {
	"use strict";

	QUnit.module("Aramcotile Controller");

	QUnit.test("I should test the Aramcotile controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});